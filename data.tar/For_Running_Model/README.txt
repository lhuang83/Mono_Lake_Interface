This includes data necessary for running the water budget model. 

Aside from variables like Mono Lake Precipitation and Evaporation,

This also includes The Actual Flow into Mono Lake (based on relationship between natural flow to regulated flow into Mono Lake)

Also included is the RYT (and SRF/SEF values) based on historical (static) conditions and dynamic conditions that take into account how the GCMs climatology/data changes in the future
